# GenAI Detection-as-Code V2 LinkedIn Launch Pack

This pack contains:

- `LinkedIn_Posts_GenAI_Detection_as_Code_V2.txt` - full 8-post series with hook options and first comments
- `Gemini_Image_Prompts_GenAI_Detection_as_Code_V2.md` - 3 main image prompts + 5 optional PDF cover prompts
- `individual_posts/` - each post separated into its own file
- `image_prompts/` - each prompt separated into its own file

## Recommended posting order

1. Flow A2 PDF post
2. Flow B2 PDF post
3. Flow C2 PDF post
4. Supporting Workflows PDF post
5. Master Overview PDF post
6. Capstone Launch image post
7. Architecture Deep-Dive image post
8. Recruiter-Focused image post

## Asset usage

- Posts 1-5: attach the matching PDF document/carousel.
- Posts 6-8: use the main Gemini-generated images.
- Optional cover prompts are included for PDF thumbnails if needed.

## Brand

abdul4rehman215 - https://www.linkedin.com/in/abdul4rehman215/
